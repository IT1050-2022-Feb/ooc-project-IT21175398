class Inquiry
{
private:
char uName[25];
int contactNo;
char uEmail[50];
char addEnquire[100];

public:
void enquire(char username[], int cNo, char useremail[], char addEnq[]);

void displayEnquire();
};
